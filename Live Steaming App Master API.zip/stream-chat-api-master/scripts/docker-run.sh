#!/bin/bash

cd ../

docker run -p80:3000 nickparsons/stream-chat-api