#!/bin/bash

cd ../

docker build . -t nickparsons/stream-chat-api